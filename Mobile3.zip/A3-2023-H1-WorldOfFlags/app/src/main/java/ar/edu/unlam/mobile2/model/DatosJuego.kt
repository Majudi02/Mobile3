package ar.edu.unlam.mobile2.model

object DatosJuego {
	var listaPaises: List<CountryModel> = listOf()
}
