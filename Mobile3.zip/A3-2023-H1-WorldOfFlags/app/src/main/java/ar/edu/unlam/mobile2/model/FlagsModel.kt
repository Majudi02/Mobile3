package ar.edu.unlam.mobile2.model

import java.io.Serializable

data class FlagsModel(
    val svg : String,
    val png : String
    ) : Serializable
